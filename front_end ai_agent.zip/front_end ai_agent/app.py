from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import logging
import os

app = Flask(__name__)
CORS(app)  
logging.basicConfig(level=logging.INFO)

def get_ai_response(user_input):
    
    user_input_lower = user_input.lower()
    
    if any(word in user_input_lower for word in ['hello', 'hi', 'hey', 'greetings']):
        return "Hello! I'm your AI Client Service Agent. How can I assist you today?"
    
    elif any(word in user_input_lower for word in ['service', 'offer', 'provide', 'what do you do']):
        return "We offer comprehensive AI-powered client services including: 24/7 support, meeting scheduling, technical assistance, and personalized recommendations. What specific service are you interested in?"
    
    elif any(word in user_input_lower for word in ['account', 'login', 'password', 'sign in']):
        return "For account-related issues, I can help with password reset, account recovery, or connect you with our support team. Please provide more details about your issue."
    
    elif any(word in user_input_lower for word in ['schedule', 'meeting', 'appointment', 'calendar']):
        return "I can help schedule meetings! Please let me know your preferred date and time, and I'll check availability with our team. You can also specify if you need a specific team member."
    
    elif any(word in user_input_lower for word in ['price', 'cost', 'pricing', 'how much']):
        return "Our pricing varies based on services and packages. I can provide general information or connect you with our sales team for detailed quotes. Are you looking for pricing on a specific service?"
    
    elif any(word in user_input_lower for word in ['help', 'support', 'assistance', 'problem']):
        return "I'm here to help! You can ask me about our services, schedule meetings, get technical support, or request information. What do you need assistance with?"
    
    elif any(word in user_input_lower for word in ['contact', 'email', 'phone', 'number']):
        return "You can reach our support team at support@idt.com or call us at +1 (555) 123-4567. Our business hours are Monday-Friday, 9 AM to 6 PM EST."
    
    elif any(word in user_input_lower for word in ['thank', 'thanks', 'appreciate']):
        return "You're welcome! Is there anything else I can help you with today?"
    
    elif any(word in user_input_lower for word in ['bye', 'goodbye', 'exit', 'end']):
        return "Thank you for chatting with me! Have a great day. Feel free to return anytime you need assistance."
    
    else:
        return "I understand you're looking for assistance. Could you please provide more details so I can help you better? You can ask about our services, schedule a meeting, or get support."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    try:
        user_input = request.json['message']
        logging.info(f"User input: {user_input}")
        
     
        import time
        time.sleep(0.5)  
        
        response = get_ai_response(user_input)
        return jsonify({'response': response})
    
    except Exception as e:
        logging.error(f"Error processing request: {e}")
        return jsonify({'response': "Sorry, I'm experiencing technical difficulties. Please try again in a moment."}), 500

if __name__ == '__main__':
 
    if not os.path.exists('templates'):
        os.makedirs('templates')
        print("Created templates directory")
    
    app.run(debug=True, host='0.0.0.0', port=5000)

